

SELECT

	-- show number of events for each continent and country
	cn.ContinentName AS Continent,
	cy.CountryName AS Country,
	COUNT(*) as 'Number of events'

FROM
	tblContinent AS cn
	INNER JOIN tblCountry AS cy
		ON cn.ContinentID = cy.ContinentID
	INNER JOIN tblEvent AS ev
		ON cy.CountryID = ev.CountryID
WHERE

	-- don't count European events
	cn.ContinentName <> 'Europe'

GROUP BY
	cn.ContinentName,
	cy.CountryName
HAVING	

	-- exclude countries with less than 5 events from total
	COUNT(*) >= 5

ORDER BY
	cy.CountryName