
SELECT
	-- show number of events for each category
	c.CategoryName,
	COUNT(*) as 'Number of events'
FROM
	tblCategory as c
	INNER JOIN tblEvent as e
		ON c.CategoryID = e.CategoryID
GROUP BY

	-- need to group by category, as included
	-- in SELECT clause without aggregating
	c.CategoryName
ORDER BY

	-- show most popular categories first
	'Number of events' DESC