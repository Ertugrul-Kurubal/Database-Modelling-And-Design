
USE DoctorWho

SELECT

	-- show the author
	a.AuthorName,

	-- show number of episodes
	COUNT(*) AS 'Episodes',

	-- show first and last ones made
	MIN(e.EpisodeDate) AS 'Earliest date',
	MAX(e.EpisodeDate) AS 'Latest date'


FROM
	tblAuthor AS a
	INNER JOIN tblEpisode AS e ON a.AuthorId = e.AuthorId

GROUP BY

	a.AuthorName

ORDER BY
	-- most prolific author first
	Episodes DESC

