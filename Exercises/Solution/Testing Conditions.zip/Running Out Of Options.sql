--Write a stored procedure that runs a different select depending on what is passed in.
CREATE PROC uspInformation 
(@Information varchar(max)) --A varchar so users can pass in a word of their choice
AS

IF @Information = 'Country' -- Consider using '%' + @Information + '%' to account for variances in what is entered
	BEGIN -- IF is a true false or boolean test. If the test returns true SQL will run the very next command, if false the next command is skiped. BEGIN END allows multiple commands to be triggered or skipped.
		SELECT top 2
			CountryName
		FROM
			tblCountry
	--RETURN would exit the script and prevent @Information being tested further if it's value was 'Country'
	END

IF @Information = 'Event'
	BEGIN
		SELECT top 2
			EventName
			,EventDetails
			,EventDate
		FROM
			tblEvent
	END


IF @Information = 'Continent'
	BEGIN
		SELECT top 2
			ContinentName
		FROM
			tblContinent
	END
--ELSE can be paired with the previous IF. The ELSE is only triggered when the corresponding IF returns FALSE.

IF @INFORMATION NOT IN ('Event','Country','Continent') --Explicitly check if @Information was one of the expected values, if it wasn't return a message.
	BEGIN
		SELECT 'You must enter: Event, Country or Continent' AS 'Nuh uh say the magic word'
	END

------------------RUN IN A SEPERATE SCRIPT-------------------------------------


--Try the stored procedure with each of the possible outcomes.
exec uspInformation 'Event'  

exec uspInformation 'Country'

exec uspInformation 'Continent'

exec uspInformation 'Something else'